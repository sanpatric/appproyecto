import React, { useEffect, useState } from 'react'
import {Link, useNavigate} from 'react-router-dom'
import '../css/Productos.css';

const Productos = () => {

  const navigate = useNavigate();
  const [ListadoProductos, setListadoProductos] = useState([]);
  const [paginaActual, setPaginaActual] = useState(1);
  const [totalRegistros, setTotalRegistros] = useState(0);
  
  useEffect(() => {
    fetchData();
  }, [paginaActual]);


  const fetchData = () => {
    const startIndice = (paginaActual - 1) * 4;
    const endIndice = startIndice + 4;
    fetch("https://645f08637da4477ba94ffd95.mockapi.io/api/v1/productos")
    .then((Listado) => Listado.json())  
    .then((Listado) => {
        const paginasData = Listado.slice(startIndice, endIndice);
        setListadoProductos(paginasData);
        setTotalRegistros(Listado.length);
    }) 
    
  }

  const sigPagina = () => {
    setPaginaActual(paginaActual + 1);
  }

  const antPagina = () => {
    setPaginaActual(paginaActual - 1);
  }
    
  return(
    <div className='container'>
      <h1 className='titulo'> PRODUCTOS </h1>
      <div className='cardContainer'>
        {ListadoProductos.map(prod =>(
          <div key={prod.id} className='card'>
            <h3><Link to={`/productos/${prod.id}`}>{prod.name}</Link></h3>
            <img src={prod.url} width="100px" height="100px" className='image'></img>
          </div>
          ))}
      </div>
      <p> Pagina {paginaActual} de {Math.ceil(totalRegistros/4)} </p>
      <button onClick={antPagina} disabled={paginaActual === 1}> Anterior </button>
      <button onClick={sigPagina} disabled={paginaActual === Math.ceil(totalRegistros/4)}> Siguiente </button>      
    </div> 
  );
}

export default Productos