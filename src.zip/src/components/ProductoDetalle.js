import React, { useEffect, useState } from 'react'
import {useParams} from 'react-router-dom'


const ProductoDetalle = () => {

  const {prodID}  = useParams();

  const [ListadoProductos, setListadoProductos] = useState([]);
  
  useEffect(() => {
    fetch("https://645f08637da4477ba94ffd95.mockapi.io/api/v1/productos")
    .then((Listado) => Listado.json())  
    .then((Listado) => {
        setListadoProductos(Listado);
    }) 
  }, []);

  const elproducto = ListadoProductos.find( product => product.id === prodID)  
    if(!elproducto){
        return(
            <h1> NO HAY PRODUCTOS </h1>
        )
    }

  return (
    <div>
        <h1> {elproducto.name} </h1>
        <img src={elproducto.url} width="100px" height="100px"></img>
        <p> Precio: {elproducto.precio} </p>
        <p> Descripcion: {elproducto.descripcion} </p>
    </div>
  )
}

export default ProductoDetalle