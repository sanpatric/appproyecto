import React from 'react'

const Inicio = () => {
  return (
    <div>Inicio</div>
  )
}

export default Inicio